public class Ex12 {
}
