public class Principal {
    public static void main (String[] args) {
        suma( 10, 20 , 5);
    }

    public static void suma(int a, int b, int c) {

        System.out.println(a + b + c);

        }

    }

