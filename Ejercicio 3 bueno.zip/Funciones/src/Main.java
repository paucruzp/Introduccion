public class Main {
    /*public static void main(String[] args) {
        suma(10, 20, 5);
    }

    public static void suma(int a, int b, int c) {

        System.out.println(a + b + c);*/

    // Esto está mla, ya que el código se repite al hacer la función. Se le llama paso por valor. También
    // se duplican los estilos de los números (int) y se ocupa el doble de memoria en ambos casos
    // Las funciones deben ser útiles y no muy largas
    // Las funciones siempre deberán llamrse dentrode sus correspondientes {}, sino no se podrán invocar
    //}


    /*public class Principal {
        public static void main(String[] args) {
            Potato MiPotato = new Potato();
            MiPotato.Quitarbrazo();
            class Potato {
                public int brazos = 0;

            }
        }

        public class Aprender {
            public static void main(String[] args) {
                String estacion = "Primavera";

                if (estacion == "Primavera"){
                    System.out.println("Es primavera!");
                } else if (estacion == "verano"){
                    System.out.println("Es verano!");
                }else{
                    System.out.println("Es otra estacion");
                }



            }
        }*/

       /* public static void main(String[] args) {
            int contador = 10;

            while (contador > 0) {
                System.out.println(contador);
                contador = contador - 1;
            }
        }*/

  /*  public static void main(String[] args) {
        int contador = 12;
        System.out.println(contador);
        do {
            contador = contador -1;
        }while (contador > 2) ;

    }*/
/* Uso for básico
    public static void main(String[] args) {
        for (int contador = 1; contador <= 10; contador ++){
        System.out.println(contador);
        }
    }*/

    //Uso for para arrays. i = posición actual dentro del bucle
   /* public static void main(String[] args) {
        int valores []= {10, 20, 30, 40, 50};

        for (int i = 0; i < valores.length; i++){
            System.out.println(valores [i]);
        }
    }*/

   /* public static void main(String[] args) {
        var estacion = "Verano";

        switch (estacion){
            case "Verano":
                System.out.println("Es verano");
                break;
            case "invierno":
                System.out.println("Es invierno");
                break;
            default:
                System.out.println(estacion);
        }
    }*/
   /* public static void main(String[] args) {
        var estacion = "Martes";

        switch (estacion) {
            case "Lunes":
            case "Martes":
            case "Miercoles":
            case "Jueves":
            case "Viernes":
                System.out.println("Es laborable");
                break;
            case "Sabado":
            case "Domingo":
                System.out.println("Es festivo");

        }
    }*/
    public static void main(String[] args) {
        var numeroif = 3;

    }

}