public class Cuartoex {
    public static void main(String[] args) {
       /* var numerowhile = -3;
        while (numerowhile < 3) {
            numerowhile++;
            System.out.println(numerowhile);
        }*/


// Do while

        /*var numerodowhile = -3;
        System.out.println(numerodowhile);
        do {
            numerodowhile++;
        } while (numerodowhile > 3);

}
        for (var numerofor = 0; numerofor <= 3; numerofor++) {
            System.out.println(numerofor);
        }*/

        var estacion = "212";
        switch (estacion) {
            case "Verano":
                System.out.println("Es verano, felicidades");
                break;
            case "Invierno":
                System.out.println("Es invierno, felicidades");
                break;
            case "Otoño":
                System.out.println("Es otoño, felicidades");
                break;
            case "Primavera":
                System.out.println("Es primavera, felicidades");
                break;
            default:
                System.out.println("Esto no es una estacion ):");
            }

        }
    }

