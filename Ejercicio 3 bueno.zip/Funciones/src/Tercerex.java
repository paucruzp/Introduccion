public class Tercerex {
    public static void main(String[] args) {
        var numeroif = 3;
        if (numeroif < 0){
            System.out.println("Es negativo");
        } else if (numeroif == 0 ) {
            System.out.println("Es igual a 0");
        }else{
            System.out.println("Es positivo");
        }

    }
}

